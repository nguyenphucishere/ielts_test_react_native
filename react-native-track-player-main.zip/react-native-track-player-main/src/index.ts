import * as TrackPlayer from './trackPlayer';

export * from './constants';
export * from './hooks';
export * from './interfaces';

export default TrackPlayer;
