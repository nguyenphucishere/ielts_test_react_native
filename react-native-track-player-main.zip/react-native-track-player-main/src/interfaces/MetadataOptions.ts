import type { UpdateOptions } from './UpdateOptions';

/** @deprecated use UpdateOptions instead */
export type MetadataOptions = UpdateOptions;
