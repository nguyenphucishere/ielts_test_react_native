export type ServiceHandler = () => Promise<void>;
