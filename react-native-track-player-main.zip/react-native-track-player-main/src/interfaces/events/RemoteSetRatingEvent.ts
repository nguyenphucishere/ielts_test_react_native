import type { RatingType } from '../../constants';

export interface RemoteSetRatingEvent {
  rating: RatingType;
}
