export interface RemoteSeekEvent {
  /** The position to seek to in seconds. */
  position: number;
}
