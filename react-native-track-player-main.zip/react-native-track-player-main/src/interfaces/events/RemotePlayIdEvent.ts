export interface RemotePlayIdEvent {
  /** The track id */
  id: string;
}
