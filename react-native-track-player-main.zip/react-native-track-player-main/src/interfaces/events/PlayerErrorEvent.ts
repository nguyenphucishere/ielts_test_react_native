export interface PlayerErrorEvent {
  /** The error code */
  code: 'android-foreground-service-start-not-allowed';
  /** The error message */
  message: string;
}
