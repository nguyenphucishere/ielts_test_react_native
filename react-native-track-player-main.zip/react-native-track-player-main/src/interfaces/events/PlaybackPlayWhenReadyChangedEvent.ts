export interface PlaybackPlayWhenReadyChangedEvent {
  /** Whether the player will play when it is ready to do so. */
  playWhenReady: boolean;
}
