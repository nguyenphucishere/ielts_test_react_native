export interface RemoteSkipEvent {
  index: number;
}
