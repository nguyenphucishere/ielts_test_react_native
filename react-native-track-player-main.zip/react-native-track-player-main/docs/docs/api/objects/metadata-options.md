# ⚠️ MetadataOptions

**⚠️ Deprecated in favor of [`UpdateOptions`](./update-options.md)**
