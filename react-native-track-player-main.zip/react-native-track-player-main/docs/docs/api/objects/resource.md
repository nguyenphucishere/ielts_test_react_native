# Resource

Resource objects are the result of `require`/`import` for files.

For more information about Resource Objects, read the [Images](https://reactnative.dev/docs/images) section of the React Native documentation
