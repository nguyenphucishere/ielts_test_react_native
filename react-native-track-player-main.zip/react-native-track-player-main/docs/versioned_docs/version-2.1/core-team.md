---
sidebar_position: 8
---

# Core Team  ✨

<table>
  <tr>
    <td align="center">
      <a href="https://github.com/dcvz">
        <img src="https://avatars.githubusercontent.com/u/2475932?v=4" width="100px;" alt=""/>
        <br /><sub><b>David Chavez</b></sub>
      </a>
      <br />
    </td>
    <td align="center">
      <a href="https://github.com/mpivchev">
        <img src="https://avatars.githubusercontent.com/u/6960329?v=4" width="100px;" alt=""/>
        <br /><sub><b>Milen Pivchev</b></sub>
      </a>
      <br />
    </td>
    <td align="center">
      <a href="https://github.com/jspizziri">
        <img src="https://avatars.githubusercontent.com/u/1452066?v=4" width="100px;" alt=""/>
        <br /><sub><b>Jacob Spizziri</b></sub>
      </a>
      <br />
    </td>
  </tr>
</table>

## Special Thanks ✨
<table>
  <tr>
    <td align="center">
      <a href="https://github.com/Guichaguri">
        <img src="https://avatars.githubusercontent.com/u/1813032?v=4" width="100px;" alt=""/>
        <br /><sub><b>Guilherme Chaguri</b></sub>
      </a>
      <br />
    </td>
    <td align="center">
      <a href="https://github.com/curiousdustin">
        <img src="https://avatars.githubusercontent.com/u/1706540?v=4" width="100px;" alt=""/>
        <br /><sub><b>Dustin Bahr</b></sub>
      </a>
      <br />
    </td>
  </tr>
</table>
