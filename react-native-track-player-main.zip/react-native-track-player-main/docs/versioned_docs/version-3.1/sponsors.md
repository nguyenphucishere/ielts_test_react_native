---
sidebar_position: 11
---

# Sponsors  ❤️

Thanks to our backers and sponsors for their generous support!

## Backers

Support us with a monthly donation and help us continue our activities. [[Become a backer](https://github.com/sponsors/doublesymmetry)]

<a href="https://github.com/drplauska" target="_blank"><img src="https://avatars.githubusercontent.com/u/10409285?v=4" width="64" /></a>
<a href="https://github.com/brianshano" target="_blank"><img src="https://avatars.githubusercontent.com/u/5247913?v=4" width="64" /></a>
<a href="https://github.com/dimadeveatii" target="_blank"><img src="https://avatars.githubusercontent.com/u/2014771?v=4" width="64" /></a>

## Sponsors

Become a sponsor and get your logo on our README on Github with a link to your site. [[Become a sponsor](https://github.com/sponsors/doublesymmetry)]

<a href="http://radio.garden/" target="_blank"><img src="https://avatars.githubusercontent.com/u/271885?v=4" width="192" /></a>
<a href="https://evergrace.co"><img src="https://avatars.githubusercontent.com/u/1085976?v=4" width="192" /></a>
<a href="https://podverse.fm"><img src="https://avatars.githubusercontent.com/u/11860029?s=200&v=4" width="192" /></a>
<a href="http://www.voxist.com/"><img src="https://avatars.githubusercontent.com/u/18028734?s=200&v=4" width="192" /></a>
