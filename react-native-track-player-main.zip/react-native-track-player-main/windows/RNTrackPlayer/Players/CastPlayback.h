#pragma once

#include "pch.h"
#include "NativeModules.h"
#include "Players/Playback.h"

namespace winrt::RNTrackPlayer {
    struct CastPlayback {
        // TODO
        // https://github.com/Tapanila/SharpCaster
        // https://docs.microsoft.com/windows/uwp/audio-video-camera/media-casting
    };
}